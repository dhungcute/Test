public class Solution {
    public int reverse(int n) {
        long rev = 0;
        while (n != 0) {
            rev = rev * 10 + n % 10;
            n /= 10;
        }
        if (rev > Integer.MAX_VALUE || rev < Integer.MIN_VALUE) {
            return 0;
        }
        return (int) rev;
    }
    public static void main(String[] args) {
        Solution sol = new Solution();
        System.out.println("Test voi 123: " + sol.reverse(123));
        System.out.println("Test voi -123: " + sol.reverse(-123));
        System.out.println("Test voi 120: " + sol.reverse(120));
        System.out.println("Test voi 0: " + sol.reverse(0));
        System.out.println("Test voi 1534236469: " + sol.reverse(1534236469));
    }
}
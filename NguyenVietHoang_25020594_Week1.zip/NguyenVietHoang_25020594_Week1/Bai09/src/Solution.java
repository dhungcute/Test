public class Solution {
    public int sumOfDigits(int n) {
        int sum = 0;
        while (n != 0) {
            int digit = n % 10;
            if (digit < 0) {
                digit = -digit;
            }
            sum += digit;
            n /= 10;
        }
        return sum;
    }
    public static void main(String[] args) {
        Solution sol = new Solution();
        System.out.println("Test voi 123: " + sol.sumOfDigits(123));
        System.out.println("Test voi -456: " + sol.sumOfDigits(-456));
        System.out.println("Test voi 0: " + sol.sumOfDigits(0));
        System.out.println("Test voi 987654321: " + sol.sumOfDigits(987654321));
    }
}
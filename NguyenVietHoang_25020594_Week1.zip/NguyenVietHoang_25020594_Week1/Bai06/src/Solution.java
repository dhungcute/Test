public class Solution {
    public boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= n / i; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        Solution sol = new Solution();
        System.out.println("Test voi -7: " + sol.isPrime(-7));
        System.out.println("Test voi 1: " + sol.isPrime(1));
        System.out.println("Test voi 2: " + sol.isPrime(2));
        System.out.println("Test voi 17: " + sol.isPrime(17));
        System.out.println("Test voi 2147483647: " + sol.isPrime(2147483647));
    }
}
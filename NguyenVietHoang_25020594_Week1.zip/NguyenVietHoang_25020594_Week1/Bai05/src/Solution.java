public class Solution {
    public int gcd(int a, int b) {
        a = Math.abs(a);
        b = Math.abs(b);
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
    public static void main(String[] args) {
        Solution sol = new Solution();
        System.out.println("gcd(15, 5) = " + sol.gcd(15, 5));
        System.out.println("gcd(17, 4) = " + sol.gcd(17, 4));
        System.out.println("gcd(-20, 8) = " + sol.gcd(-20, 8));
        System.out.println("gcd(0, 12) = " + sol.gcd(0, 12));
        System.out.println("gcd(0, 0) = " + sol.gcd(0, 0));
    }
}
public class Solution {
    public boolean isPalindrome(int n) {
        if (n < 0) {
            return false;
        }
        long original = n;
        long reversed = 0;
        int temp = n;
        while (temp > 0) {
            reversed = reversed * 10 + temp % 10;
            temp /= 10;
        }
        return original == reversed;
    }
    public static void main(String[] args) {
        Solution sol = new Solution();
        System.out.println("Test voi -121: " + sol.isPalindrome(-121));
        System.out.println("Test voi 10: " + sol.isPalindrome(10));
        System.out.println("Test voi 0: " + sol.isPalindrome(0));
        System.out.println("Test voi 1221: " + sol.isPalindrome(1221));
        System.out.println("Test voi 2147447412: " + sol.isPalindrome(2147447412));
    }
}
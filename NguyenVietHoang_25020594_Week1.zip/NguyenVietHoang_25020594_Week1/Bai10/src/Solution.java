public class Solution {
    public int secondLargest(int[] arr) {
        if (arr == null || arr.length < 2) {
            return -1;
        }
        Integer max = null;
        Integer secondMax = null;
        for (int num : arr) {
            if (max == null || num > max) {
                secondMax = max;
                max = num;
            } else if (num < max && (secondMax == null || num > secondMax)) {
                secondMax = num;
            }
        }
        if (secondMax == null) {
            return -1;
        }
        return secondMax;
    }
    public static void main(String[] args) {
        Solution sol = new Solution();
        System.out.println("[1, 5, 2, 4, 3]: " + sol.secondLargest(new int[]{1, 5, 2, 4, 3}));
        System.out.println("[5, 5, 5, 2, 2]: " + sol.secondLargest(new int[]{5, 5, 5, 2, 2}));
        System.out.println("[10]: " + sol.secondLargest(new int[]{10}));
        System.out.println("[7, 7, 7]: " + sol.secondLargest(new int[]{7, 7, 7}));
        System.out.println("[-5, -1, -10, -2]: " + sol.secondLargest(new int[]{-5, -1, -10, -2}));
    }
}
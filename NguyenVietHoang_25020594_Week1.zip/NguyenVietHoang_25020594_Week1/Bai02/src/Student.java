public class Student {
    public static void main() {
        System.out.println("test IDE");
    }
}